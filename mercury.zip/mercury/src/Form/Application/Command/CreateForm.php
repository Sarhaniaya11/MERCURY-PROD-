<?php

declare(strict_types=1);

namespace App\Form\Application\Command;

final class CreateForm
{
    public function __construct(
        public readonly string $formNumber,
        public readonly int $width,
        public readonly int $height,
        public readonly string $qualityCode,
    ) {}
}
