<?php

declare(strict_types=1);

namespace App\Form\Application\Handler;

use App\Form\Application\Command\CreateForm;
use App\Form\Domain\Form;
use App\Form\Domain\Repository\FormRepositoryInterface;

final class CreateFormHandler
{
    public function __construct(
        private readonly FormRepositoryInterface $formRepository,
    ) {}

    public function __invoke(CreateForm $command): string
    {
        $formId = self::generateUuidV4();

        $form = Form::create(
            formId: $formId,
            formNumber: $command->formNumber,
            width: $command->width,
            height: $command->height,
            qualityCode: $command->qualityCode,
        );

        $this->formRepository->save($form);

        return $formId;
    }

    private static function generateUuidV4(): string
    {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
