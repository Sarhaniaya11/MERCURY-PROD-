<?php

declare(strict_types=1);

namespace App\Form\Domain\Repository;

use App\Form\Domain\Form;

interface FormRepositoryInterface
{
    public function save(Form $form): void;
}
