<?php

declare(strict_types=1);

namespace App\Form\Domain;

use App\Form\Domain\Event\FormWasCreated;
use App\Shared\Domain\AggregateRoot;

final class Form extends AggregateRoot
{
    private function __construct(
        private readonly string $formId,
        private readonly string $formNumber,
        private readonly int $width,
        private readonly int $height,
        private readonly string $qualityCode,
    ) {}

    public static function create(
        string $formId,
        string $formNumber,
        int $width,
        int $height,
        string $qualityCode,
    ): self {
        if ($width <= 0 || $height <= 0) {
            throw new \InvalidArgumentException('Width and height must be greater than 0.');
        }

        $form = new self($formId, $formNumber, $width, $height, $qualityCode);

        $form->recordThat(new FormWasCreated(
            formId: $formId,
            formNumber: $formNumber,
            width: $width,
            height: $height,
            qualityCode: $qualityCode,
        ));

        return $form;
    }

    public function formId(): string
    {
        return $this->formId;
    }

    public function formNumber(): string
    {
        return $this->formNumber;
    }

    public function width(): int
    {
        return $this->width;
    }

    public function height(): int
    {
        return $this->height;
    }

    public function qualityCode(): string
    {
        return $this->qualityCode;
    }
}
