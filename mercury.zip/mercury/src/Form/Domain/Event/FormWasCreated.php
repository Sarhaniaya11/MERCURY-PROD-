<?php

declare(strict_types=1);

namespace App\Form\Domain\Event;

final class FormWasCreated
{
    public function __construct(
        public readonly string $formId,
        public readonly string $formNumber,
        public readonly int $width,
        public readonly int $height,
        public readonly string $qualityCode,
    ) {}
}
