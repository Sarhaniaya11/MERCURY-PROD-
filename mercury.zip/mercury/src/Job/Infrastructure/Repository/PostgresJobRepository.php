<?php

declare(strict_types=1);

namespace App\Job\Infrastructure\Repository;

use App\Job\Domain\Job;
use App\Shared\Infrastructure\Persistence\PostgresEventStore;

final class PostgresJobRepository
{
    private const STREAM_PREFIX = 'job-';

    public function __construct(
        private readonly PostgresEventStore $eventStore,
    ) {}

    public function save(Job $job): void
    {
        $this->eventStore->appendToStream(
            self::STREAM_PREFIX . $job->jobId(),
            $job->getRecordedEvents(),
        );
    }

    public function load(string $jobId): Job
    {
        $events = $this->eventStore->loadStream(self::STREAM_PREFIX . $jobId);

        return Job::reconstituteFromEvents($events);
    }
}
