<?php

declare(strict_types=1);

namespace App\Job\Application\Handler;

use App\Job\Application\Command\UpdateJobState;
use App\Job\Infrastructure\Repository\PostgresJobRepository;
use App\Shared\Domain\ValueObject\StepState;

final class UpdateJobStateHandler
{
    public function __construct(
        private readonly PostgresJobRepository $jobRepository,
    ) {}

    public function __invoke(UpdateJobState $command): void
    {
        $job = $this->jobRepository->load($command->jobId);

        $newStatus = StepState::from($command->status);

        $job->changeState($command->machineId, $newStatus);

        $this->jobRepository->save($job);
    }
}
