<?php

declare(strict_types=1);

namespace App\Job\Application\Command;

final class UpdateJobState
{
    public function __construct(
        public readonly string $jobId,
        public readonly string $machineId,
        public readonly string $status,
    ) {}
}
