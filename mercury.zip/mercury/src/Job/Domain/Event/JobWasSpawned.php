<?php

declare(strict_types=1);

namespace App\Job\Domain\Event;

use App\Shared\Domain\ValueObject\StepState;

final class JobWasSpawned
{
    public function __construct(
        public readonly string $jobId,
        public readonly string $formVersionId,
        public readonly StepState $status,
    ) {}
}
