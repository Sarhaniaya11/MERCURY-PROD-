<?php

declare(strict_types=1);

namespace App\Job\Domain\Event;

use App\Shared\Domain\ValueObject\StepState;

final class JobStateChanged
{
    public function __construct(
        public readonly string $jobId,
        public readonly string $machineId,
        public readonly StepState $status,
        public readonly \DateTimeImmutable $changedAt,
    ) {}
}
