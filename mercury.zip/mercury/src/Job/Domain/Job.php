<?php

declare(strict_types=1);

namespace App\Job\Domain;

use App\Job\Domain\Event\JobStateChanged;
use App\Job\Domain\Event\JobWasSpawned;
use App\Shared\Domain\AggregateRoot;
use App\Shared\Domain\ValueObject\StepState;

final class Job extends AggregateRoot
{
    private string $jobId;
    private string $formVersionId;
    private StepState $currentStatus;

    private function __construct() {}

    public static function spawn(string $jobId, string $formVersionId): self
    {
        $event = new JobWasSpawned($jobId, $formVersionId, StepState::WAITING_FOR_MANUFACTURING);

        $job = new self();
        $job->applyJobWasSpawned($event);
        $job->recordThat($event);

        return $job;
    }

    public function changeState(string $machineId, StepState $newStatus): void
    {
        $event = new JobStateChanged(
            $this->jobId,
            $machineId,
            $newStatus,
            new \DateTimeImmutable('now'),
        );

        $this->applyJobStateChanged($event);
        $this->recordThat($event);
    }

    public static function reconstituteFromEvents(array $events): self
    {
        $job = new self();

        foreach ($events as $event) {
            $job->applyEvent($event);
        }

        return $job;
    }

    private function applyEvent(object $event): void
    {
        match (get_class($event)) {
            JobWasSpawned::class   => $this->applyJobWasSpawned($event),
            JobStateChanged::class => $this->applyJobStateChanged($event),
        };
    }

    private function applyJobWasSpawned(JobWasSpawned $event): void
    {
        $this->jobId = $event->jobId;
        $this->formVersionId = $event->formVersionId;
        $this->currentStatus = $event->status;
    }

    private function applyJobStateChanged(JobStateChanged $event): void
    {
        $this->currentStatus = $event->status;
    }

    public function jobId(): string
    {
        return $this->jobId;
    }

    public function formVersionId(): string
    {
        return $this->formVersionId;
    }

    public function currentStatus(): StepState
    {
        return $this->currentStatus;
    }
}
