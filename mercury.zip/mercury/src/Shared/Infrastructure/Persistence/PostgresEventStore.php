<?php

declare(strict_types=1);

namespace App\Shared\Infrastructure\Persistence;

final class PostgresEventStore
{
    public function __construct(
        private readonly \PDO $pdo,
    ) {}

    /**
     * @param object[] $events
     */
    public function appendToStream(string $streamName, array $events): void
    {
        if ([] === $events) {
            return;
        }

        $sql = 'INSERT INTO event_streams (id, stream_name, event_name, payload, created_at) VALUES (:id, :stream_name, :event_name, :payload, :created_at)';
        $stmt = $this->pdo->prepare($sql);

        $now = (new \DateTimeImmutable('now'))->format('Y-m-d H:i:s.u');

        foreach ($events as $event) {
            $stmt->execute([
                ':id'          => self::generateUuidV4(),
                ':stream_name' => $streamName,
                ':event_name'  => get_class($event),
                ':payload'     => json_encode($this->serializePayload($event), JSON_THROW_ON_ERROR),
                ':created_at'  => $now,
            ]);
        }
    }

    /**
     * Extrait les propriétés publiques d'un événement.
     * Traite les DateTimeImmutable en chaîne ISO 8601 pour la sérialisation JSON.
     */
    private function serializePayload(object $event): array
    {
        $payload = [];
        $reflection = new \ReflectionObject($event);

        foreach ($reflection->getProperties(\ReflectionProperty::IS_PUBLIC) as $prop) {
            $value = $prop->getValue($event);

            if ($value instanceof \DateTimeImmutable) {
                $payload[$prop->getName()] = $value->format(\DateTimeInterface::ATOM);
            } else {
                $payload[$prop->getName()] = $value;
            }
        }

        return $payload;
    }

    /**
     * Reconstruit la liste des événements d'un stream dans l'ordre chronologique.
     *
     * @return object[]
     */
    public function loadStream(string $streamName): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT event_name, payload FROM event_streams WHERE stream_name = :stream_name ORDER BY created_at ASC'
        );
        $stmt->execute([':stream_name' => $streamName]);
        $rows = $stmt->fetchAll();

        $events = [];
        foreach ($rows as $row) {
            $events[] = $this->deserializeEvent($row['event_name'], $row['payload']);
        }

        return $events;
    }

    /**
     * Hydrate un objet événement à partir de son FQCN et de son payload JSON.
     * Gère les types scalaires, DateTimeImmutable, et les enums StepState.
     */
    private function deserializeEvent(string $eventName, string $payloadJson): object
    {
        $data = json_decode($payloadJson, true, 512, JSON_THROW_ON_ERROR);
        $reflection = new \ReflectionClass($eventName);
        $constructor = $reflection->getConstructor();

        if (null === $constructor) {
            throw new \RuntimeException(sprintf('Event %s has no constructor.', $eventName));
        }

        $args = [];
        foreach ($constructor->getParameters() as $param) {
            $name  = $param->getName();
            $type  = $param->getType();
            $value = $data[$name] ?? null;

            if ($type instanceof \ReflectionNamedType) {
                $value = match ($type->getName()) {
                    \DateTimeImmutable::class  => new \DateTimeImmutable($data[$name]),
                    \App\Shared\Domain\ValueObject\StepState::class => \App\Shared\Domain\ValueObject\StepState::from($data[$name]),
                    default                   => $data[$name] ?? null,
                };
            }

            $args[] = $value;
        }

        return $reflection->newInstanceArgs($args);
    }

    private static function generateUuidV4(): string
    {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
