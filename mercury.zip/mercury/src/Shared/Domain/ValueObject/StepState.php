<?php

declare(strict_types=1);

namespace App\Shared\Domain\ValueObject;

enum StepState: string
{
    case WAITING_FOR_MANUFACTURING = 'waiting_for_manufacturing';
    case PLANNED                   = 'planned';
    case IN_PROGRESS               = 'in_progress';
    case DONE                      = 'done';
}
