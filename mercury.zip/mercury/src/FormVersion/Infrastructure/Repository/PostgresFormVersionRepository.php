<?php

declare(strict_types=1);

namespace App\FormVersion\Infrastructure\Repository;

use App\FormVersion\Domain\FormVersion;
use App\FormVersion\Domain\Repository\FormVersionRepositoryInterface;
use App\Shared\Infrastructure\Persistence\PostgresEventStore;

final class PostgresFormVersionRepository implements FormVersionRepositoryInterface
{
    private const STREAM_NAME = 'form_version';

    public function __construct(
        private readonly PostgresEventStore $eventStore,
    ) {}

    public function save(FormVersion $formVersion): void
    {
        $events = $formVersion->getRecordedEvents();

        $this->eventStore->appendToStream(self::STREAM_NAME, $events);
    }
}
