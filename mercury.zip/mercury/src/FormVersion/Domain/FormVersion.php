<?php

declare(strict_types=1);

namespace App\FormVersion\Domain;

use App\FormVersion\Domain\Event\FormVersionWasCreated;
use App\Shared\Domain\AggregateRoot;

final class FormVersion extends AggregateRoot
{
    private function __construct(
        private readonly string $formVersionId,
        private readonly string $formId,
        private readonly string $machineId,
        private readonly \DateTimeImmutable $scheduledStartDate,
        private readonly \DateTimeImmutable $expectedFinishDate,
    ) {}

    public static function plan(
        string $formVersionId,
        string $formId,
        string $machineId,
        \DateTimeImmutable $scheduledStartDate,
        \DateTimeImmutable $expectedFinishDate,
    ): self {
        $now = new \DateTimeImmutable('now');

        if ($scheduledStartDate <= $now) {
            throw new \InvalidArgumentException('Scheduled start date must be in the future.');
        }

        $version = new self(
            $formVersionId,
            $formId,
            $machineId,
            $scheduledStartDate,
            $expectedFinishDate,
        );

        $version->recordThat(new FormVersionWasCreated(
            formVersionId: $formVersionId,
            formId: $formId,
            machineId: $machineId,
            scheduledStartDate: $scheduledStartDate,
            expectedFinishDate: $expectedFinishDate,
        ));

        return $version;
    }
}
