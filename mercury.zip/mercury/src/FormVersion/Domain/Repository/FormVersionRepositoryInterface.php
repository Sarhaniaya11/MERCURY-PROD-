<?php

declare(strict_types=1);

namespace App\FormVersion\Domain\Repository;

use App\FormVersion\Domain\FormVersion;

interface FormVersionRepositoryInterface
{
    public function save(FormVersion $formVersion): void;
}
