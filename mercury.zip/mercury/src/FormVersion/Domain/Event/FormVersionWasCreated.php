<?php

declare(strict_types=1);

namespace App\FormVersion\Domain\Event;

final class FormVersionWasCreated
{
    public function __construct(
        public readonly string $formVersionId,
        public readonly string $formId,
        public readonly string $machineId,
        public readonly \DateTimeImmutable $scheduledStartDate,
        public readonly \DateTimeImmutable $expectedFinishDate,
    ) {}
}
