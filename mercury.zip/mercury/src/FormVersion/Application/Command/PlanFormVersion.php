<?php

declare(strict_types=1);

namespace App\FormVersion\Application\Command;

final class PlanFormVersion
{
    public function __construct(
        public readonly string $formId,
        public readonly string $machineId,
        public readonly \DateTimeImmutable $scheduledStartDate,
    ) {}
}
