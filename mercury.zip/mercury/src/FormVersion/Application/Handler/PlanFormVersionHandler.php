<?php

declare(strict_types=1);

namespace App\FormVersion\Application\Handler;

use App\FormVersion\Application\Command\PlanFormVersion;
use App\FormVersion\Domain\FormVersion;
use App\FormVersion\Domain\Repository\FormVersionRepositoryInterface;

final class PlanFormVersionHandler
{
    public function __construct(
        private readonly FormVersionRepositoryInterface $formVersionRepository,
    ) {}

    public function __invoke(PlanFormVersion $command): string
    {
        $formVersionId = self::generateUuidV4();

        $expectedFinishDate = $command->scheduledStartDate->modify('+2 hours');

        $formVersion = FormVersion::plan(
            formVersionId: $formVersionId,
            formId: $command->formId,
            machineId: $command->machineId,
            scheduledStartDate: $command->scheduledStartDate,
            expectedFinishDate: $expectedFinishDate,
        );

        $this->formVersionRepository->save($formVersion);

        return $formVersionId;
    }

    private static function generateUuidV4(): string
    {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
